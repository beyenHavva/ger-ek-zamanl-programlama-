
package MazeSolverProject;

/**
 * Bir labirentte tek bir hücre. Her hücrenin bir üst duvarı,
 * bir sol duvarı, iki çözüm işaretçi ve hücrenin henüz son
 * labirentin parçası olup olmadığını gösteren bir işaretçi vardır..
 */
class MazeCell {
    private boolean top = true;
    private boolean left = true;
    private boolean used = false;

    /** Hücrenin bir çözüm yolunun parçası olduğunu gösterir. */
    private boolean solution = false;

    /** Hücrenin bir hata çözümünün parçası olduğunu gösterir. */
    private boolean error = false;

    /**
     * Hücre bir hata yolunun parçasıysa true döndürür.
     * @return true hücre bir hata yolunun parçasıysa true döndür
     */
    public final boolean isError() {
        return error;
    }

    /**
     * Hücre bir çözüm yolunun parçasıysa true döndürür
     * @return true Hücre bir çözüm yolunun parçasıysa true döndürür
     */
    public final boolean isSolution() {
        return solution;
    }

    /**
     * Hücrenin üst duvarı varsa true döndürür.
     * @return true Hücrenin üst duvarı varsa true döndürür.
     */
    public final boolean hasTopWall() {
        return top;
    }

    /**
     * Hücrenin sol duvarı varsa true döndürür.
     * @return true Hücrenin sol duvarı varsa true döndürür.
     */
    public final boolean hasLeftWall() {
        return left;
    }

    /**
     * Geçerli labirentte hücre kullanılmışsa true değerini döndürür.
     * @return true Geçerli labirentte hücre kullanılmışsa true 
     * değerini döndürür.
     */
    public final boolean isUsed() {
        return used;
    }

    /**
     * Bu hücreyi bir çözüm hücresi olarak işaretler.
     */
    public final void markSolution() {
        solution = true;
    }

    /**
     * Bu hücreyi bir hata hücresi olarak işaretler
     */
    public final void markError() {
        solution = false;
        error = true;
    }

    /**
     * Bu hücrenin sol duvarını kaldırır
     */
    public final void breakLeft() {
        left = false;
    }

    /**
     * Bu hücrenin sağ duvarını kaldırır
     */
    public final void breakTop() {
        top = false;
    }

    /**
     * Bu hücreyi kullanılmış olarak işaretler.
     */
    public final void markUsed() {
        used = true;
    }
}
