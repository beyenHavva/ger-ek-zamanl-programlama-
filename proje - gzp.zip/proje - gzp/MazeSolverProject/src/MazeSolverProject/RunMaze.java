
package MazeSolverProject;

import javax.swing.JFrame;

/**
 * Bağımsız bir uygulama olarak bir animasyon ayarlama
 */
public final class RunMaze {

    private static final int WIDTH = 40;
    private static final int HEIGHT = 40;
    private static final int SCALE = 15;
    private static final int SPEED = 20;

    private static final int WIDTH_ARG = 0;
    private static final int HEIGHT_ARG = 1;
    private static final int SCALE_ARG = 2;
    private static final int SPEED_ARG = 2;

    /** Gizli yapıcı. */
    private RunMaze() {
    }

    /**
     * Ana işlev.
     * @param args  komut satırı argümanları
     */
    public static void main(final String[] args) {
        /* Zayıf OpenJDK performansı için düzeltme. */
        System.setProperty("sun.java2d.pmoffscreen", "false");

        /* Varsayılan labirent davranışı */
        int width = WIDTH;
        int height = HEIGHT;
        int scale = SCALE;
        int speed = SPEED;

        /* Giriş bağımsız değişkenlerini ayrıştırma */
        if (args.length > 0) {
            try {
                width = Integer.parseInt(args[WIDTH_ARG]);
                if (args.length > HEIGHT_ARG) {
                    height = Integer.parseInt(args[HEIGHT_ARG]);
                }
                if (args.length > SCALE_ARG) {
                    scale = Integer.parseInt(args[SCALE_ARG]);
                }
                if (args.length > SPEED_ARG) {
                    speed = Integer.parseInt(args[SPEED_ARG]);
                }
            } catch (NumberFormatException e) {
                System.err.println("Arguments must be integers");
                System.exit(1);
            }
        }

        Maze maze = new DepthMaze(width, height, scale);
        JFrame frame = new JFrame("Maze");
        MazeDisplay display = new MazeDisplay(maze);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(display);
        frame.pack();
        frame.setResizable(false);
        frame.setVisible(true);

        /* Şimdi labirenti çöz */
        MazeSolver solver = new MazeSolver(maze, speed);
        solver.addListener(display);
        solver.start();
    }
}