
package MazeSolverProject;

/**
 * Bilinmeyen şekil ve özelliklere sahip genel bir labirent..
 * Hücreler, labirentin yolunu tarif ederek birbirine bağlanır.
 * Bu hücre ağı, labirent yapıcısı tarafından oluşturulmalı ve
 * ilk hücre start() ile döndürülmelidir.
 * 
 * Yineleme, görüntüleme amacıyla sağlanır, labirentteki her 
 * hücreyi tekrarlamak için -- hücrenin bağlılığından bağımsız 
 * olarak sipariş vermek
 */
public interface Maze extends Iterable<Cell> {

    /**
     * Labirentin ölçülen genişliği. Bu, hücreler açısından 
     * labirentin genişliği değil, görüntülenen genişliktir.
     * Örneğin, her hücrenin 5 birim genişliğinde olduğu 5
     * hücre genişliğinde dikdörtgen bir labirent, labirent 
     * 25 birim genişliğinde olacaktır.
     * @return labirentin ölçülen genişliğini döndür
     */
    int getWidth();

    /**
     * Labirentin ölçülen yüksekliği. getWidth()'e bakın.
     * @return labirentin ölçülen yüksekliğini döndür
     */
    int getHeight();

    /**
     * Bu labirentin başlangıç ​​hücresini döndürün. Hücreler
     * diğerlerine bağlanır hücreler ve labirenti "oynatılır", 
     * bunları takip etme meselesidir
     * Yinelenebilir arabirimin bir parçası olarak döndürülen
     * Yineleyici, yalnızca tüm hücreleri herhangi bir sırayla
     * tam olarak bir kez yinelemek için.
     * @return labirentin başlangıç ​​hücresini döndür
     */
    Cell start();
}

