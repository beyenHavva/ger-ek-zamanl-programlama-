
package MazeSolverProject;

import java.util.Deque;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Bir labirenti yavaş bir hızda eşzamansız olarak çözer..
 */
class MazeSolver implements Runnable {

    public static final Mark ERROR_MARK = Mark.get("error");
    public static final Mark SOLUTION_MARK = Mark.get("solution");

    private final Maze maze;
    private final int sleepTime;

    private volatile boolean enabled;
    private Collection<SolverListener> listeners
    = new CopyOnWriteArrayList<SolverListener>();

    /**
     * Verilen labirent için yeni bir çözücü oluşturur.
     * @param bulmacası çözülecek labirent
     * @param adımlar arasında uyku süresi param uyku
     */
    public MazeSolver(final Maze puzzle, final int sleep) {
        maze = puzzle;
        sleepTime = sleep;
        (new Thread(this)).start();
    }

    /**
     * Çözücü dizisini başlatın.
     */
    public void start() {
        enabled = true;
    }

    /**
     * Çözüm iş parçacığını duraklatın.
     */
    public void stop() {
        enabled = false;
    }

    @Override
    public void run() {
        Deque<Cell> stack = new ArrayDeque<Cell>();
        stack.push(maze.start());
        stack.peek().mark(SOLUTION_MARK);

        while (!stack.peek().hasMark(Cell.END)) {
            try {
                Thread.sleep(sleepTime);
            } catch (Exception e) {
                return;
            }
            if (!enabled) {
                continue;
            }

            Cell current = stack.peek();
            Collection<Cell> dirs = current.neighbors();

            boolean found = false;
            for (Cell next : dirs) {
                if (next.hasMark(ERROR_MARK) || next.hasMark(SOLUTION_MARK)) {
                    continue;
                }
                stack.push(next);
                next.mark(SOLUTION_MARK);
                found = true;
                break;
            }
            if (!found) {
                stack.pop().mark(ERROR_MARK);
            }
            for (SolverListener listener : listeners) {
                listener.solveStep();
            }
        }
        for (SolverListener listener : listeners) {
            listener.solveDone();
        }
    }

    /**
     * Bu çözücüye yeni bir SolverListener katılsın.
     * @param dinleyici yeni katılanı
     */
    public final void addListener(final SolverListener listener) {
        listeners.add(listener);
    }
}
