
package MazeSolverProject;
import java.awt.Color;
import java.awt.Stroke;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.BasicStroke;

import javax.swing.JPanel;

/**
 * Kullanıcıya bir GUI bileşeni olarak bir labirent görüntüler.
 */
class MazeDisplay extends JPanel implements SolverListener {
    private static final long serialVersionUID = 1L;

    private static final Stroke WALL_STROKE = new BasicStroke(1);

    /* Renk uyumu. */
    private static final Color SOLUTION = Color.GREEN;
    private static final Color ERROR = Color.RED;
    private static final Color WALL = Color.BLACK;

    private Maze maze;

    /**
     * Verilen labirenti verilen boyutta göster.
     * @param view görüntülenecek labirenti görüntüle
     */
    public MazeDisplay(final Maze view) {
        super();
        setMaze(view);
    }

    @Override
    public void paintComponent(final Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics;
        double scaleX = getWidth() * 1.0 / maze.getWidth();
        double scaleY = getHeight() * 1.0 / maze.getHeight();
        g.scale(scaleX, scaleY);
        g.setStroke(WALL_STROKE);
        for (Cell cell : maze) {
            if (cell.hasMark(MazeSolver.ERROR_MARK)) {
                g.setColor(ERROR);
                g.fill(cell.getShape());
            } else if (cell.hasMark(MazeSolver.SOLUTION_MARK)) {
                g.setColor(SOLUTION);
                g.fill(cell.getShape());
            }
            g.setColor(WALL);
            g.draw(cell.getWalls());
        }
    }

    /**
     * Bu ekrana yeni bir labirent atayın.
     * @param view görüntülenecek yeni labirenti görüntüle
     */
    public void setMaze(final Maze view) {
        maze = view;
        Dimension size = new Dimension(maze.getWidth(), maze.getHeight());
        setMinimumSize(size);
        setPreferredSize(size);
        repaint();
    }

    @Override
    public final void solveDone() {
        repaint();
    }

    @Override
    public final void solveStep() {
        repaint();
    }
}