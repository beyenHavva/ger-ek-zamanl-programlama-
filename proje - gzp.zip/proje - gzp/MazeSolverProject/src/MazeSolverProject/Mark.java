
package MazeSolverProject;

import java.util.Map;
import java.util.HashMap;

/**
 * Labirent oluşturmak ve çözmek için hücre meta verileri. İşaretler,
 * eşitlik operatörü (==) ile karşılaştırılabilmeleri için enterne edilir..
 */
public final class Mark {

    private static final Map<String, Mark> TABLE = new HashMap<String, Mark>();

    private final String name;

    /**
     * Verilen adla yeni bir işaret oluşturur.
     * @param markName yeni işaretin adı            
     */
    private Mark(final String markName) {
        name = markName;
    }

    /**
     * Verilen adla işareti oluşturun veya getirin. 
     * Bu işlev iş parçacığı için güvenlidir.
     * @param name adı talep edilen işaretin adı
     * @return istenen işareti iade et
     */
    public static synchronized Mark get(final String name) {
        Mark mark = TABLE.get(name);
        if (mark == null) {
            mark = new Mark(name);
            TABLE.put(name, mark);
        }
        return mark;
    }
}
