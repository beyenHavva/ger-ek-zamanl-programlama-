
package MazeSolverProject;

/**
 * Çözücü olaylarına katılmak için arayüz.
 */
public interface SolverListener {

    /**
     * Labirent başarıyla çözüldüğünde çağrılır.
     */
    void solveDone();

    /**
     * Potansiyel çözüm güncellendiğinde çağrılır.
     */
    void solveStep();
}
