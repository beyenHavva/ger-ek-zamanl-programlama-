
package MazeSolverProject;

import java.util.Set;
import java.util.HashSet;
import java.util.Collection;

import java.awt.Shape;

/**
 * Dallanma konumunu temsil eden bir labirentin en küçük birimi.
 * Bir hücre, görsel temsilini ve bağlantı hücrelerini bilir..
 */
public abstract class Cell {

    private static final int INIT_MARKS = 4;

    /** Bu hücrenin labirentin sonu olduğuna dair işaretler. */
    public static final Mark END = Mark.get("end");

    private Set<Mark> marks = new HashSet<Mark>(INIT_MARKS);

    /**
     * Bir hücreyi tanımlayan bir Şekil döndürür.
     * @return hücrenin kenarlığını açıklayan bir Şekil döndür.
     */
    public abstract Shape getShape();

    /**
     * Yalnızca hücrenin duvarlarını tanımlayan bir Şekil döndürür.
     * @return hücrenin duvarlarını tanımlayan bir şekil döndürür
     */
    public abstract Shape getWalls();

    /**
     * Bağlanan hücrelerin bir koleksiyonunu döndürür.
     * @return buna bağlı bir hücre topluluğu
     */
    public abstract Collection<Cell> neighbors();

    /**
     * Bu hücreyi verilen işaretleyiciyle işaretler.
     * @param işaretçisi bu hücreye eklenecek işaretçi
     */
    public final void mark(final Mark marker) {
        marks.add(marker);
    }

    /**
     * Bu hücre verilen işaretleyiciyle işaretlenmişse true döndürür.
     * @param işaretçisi test edilecek işaretçi
     * @return true bu hücre bu işaretleyici ile işaretlenmişse true döndürür
     */
    public final boolean hasMark(final Mark marker) {
        return marks.contains(marker);
    }
}
